/*

  dogmspi.c
  
  (c) 2010 Oliver Kraus (olikraus@gmail.com)
  
  spi abstraction layer
  
  This file is part of the dogm128 library.

  The dogm128 library is free software: you can redistribute it and/or modify
  it under the terms of the Lesser GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  The dogm128 library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  Lesser GNU General Public License for more details.

  You should have received a copy of the Lesser GNU General Public License
  along with dogm128.  If not, see <http://www.gnu.org/licenses/>.


  ST7565R SPI interface
  
    ST7565R reads data with rising edge of the clock signal (SCL)
      --> CPHA = 0 and CPOL = 0
    ST7565R reads  MSB first 
      --> DORD = 0
      


*/


/*=======================================================================*/
/* Atmel NGW100/AP7000 Linux SPI */
/*=======================================================================*/


#include <stdint.h>
#include <unistd.h>	// file access
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

#include "dogm128.h"



static int spi_fd;

void dog_spi_open(void) {

      printf("dog_spi_open: Entering\n");

	  static const char *device ="/dev/spidev0.1";


	  spi_fd =open(device, O_RDWR);
	  if (spi_fd < 0) {
		  printf("dog_spi_init: Can't open spidev0.1\n");
		  exit(1);
	  }
}

unsigned char dog_spi_out(unsigned char data)
{
	  size_t len;
	  len = 1;
      char buf[1];

      buf[0] = data;

	write(spi_fd, buf ,len);

 //   printf("dogm_spi_out: %02X\n", buf[0]);

    return 1;

}


int dog_display_reset(void) {

	printf("dog_display_reset: Entering\n");

	//  Time to export our GPIOs needed by DOGM128

	  FILE *fp;
	  fp = fopen("/sys/class/gpio/export","ab");
	  if (fp == NULL) {
		  printf("Can't open /sys/class/gpio/export\n");
		  return 0;
	  }

	  char gpio_num[4];

	  rewind(fp);
	  strcpy(gpio_num,"21");  // A0 on DOGM128 display
	  fwrite(&gpio_num, sizeof(char),2 , fp);
	  rewind(fp);
	  strcpy(gpio_num,"22");  // RST* on DOGM128 Display
	  fwrite(&gpio_num, sizeof(char),2 , fp);
	  fclose(fp);

	  // Direction for GPIO22
	  fp = fopen("/sys/class/gpio/gpio22/direction","rb+");
	  if (fp == NULL) {
		  printf("Can't open /sys/class/gpio/gpio22/direction\n");
		  return 0;
	  }

	  rewind(fp);
	  strcpy(gpio_num,"out");  // Make RST* output
	  fwrite(&gpio_num, sizeof(char) ,3 , fp);
	  fclose(fp);

	  // Direction for GPIO21
	  fp = fopen("/sys/class/gpio/gpio21/direction","rb+");
	  if (fp == NULL) {
		  printf("Can't open /sys/class/gpio/gpio21/direction\n");
		  return 0;
	  }

	  rewind(fp);
	  strcpy(gpio_num,"out");  // Make A0 output
	  fwrite(&gpio_num, sizeof(char) ,3 , fp);
	  fclose(fp);


	  // Do a reset of Display
	  fp = fopen("/sys/class/gpio/gpio22/value","rb+");
	  if (fp == NULL) {
		  printf("Can't open /sys/class/gpio/gpio22/value\n");
		  return 0;
	  }
	  rewind(fp);
	  strcpy(gpio_num,"1");  // Write 1
	  fwrite(&gpio_num, sizeof(char) ,1 , fp);
	  fclose(fp);

	  fp = fopen("/sys/class/gpio/gpio22/value","rb+");
	  if (fp == NULL) {
		  printf("Can't open /sys/class/gpio/gpio22/value\n");
		  return 0;
	  }
	  rewind(fp);
	  strcpy(gpio_num,"0");  // Write 0
	  fwrite(&gpio_num, sizeof(char) ,1 , fp);
	  fclose(fp);


	  usleep( 100000 );	// 0.1 sec delay

	  fp = fopen("/sys/class/gpio/gpio22/value","rb+");
	  if (fp == NULL) {
		  printf("Can't open /sys/class/gpio/gpio22/value\n");
		  return 0;
	  }
	  rewind(fp);
	  strcpy(gpio_num,"1");  // Write 1
	  fwrite(&gpio_num, sizeof(char) ,1 , fp);
	  fclose(fp);

	  usleep( 100000 );	// 0.1 sec delay

	  return 1;

}



void dog_cmd_mode(void)
{
	  FILE *fp;
	  char gpio_value[4];


	  fp = fopen("/sys/class/gpio/gpio21/value","rb+");
	  if (fp == NULL) {
		  printf("dog_cmd_mode: Can't open /sys/class/gpio/gpio21/value\n");
		  return;
	  }
	  rewind(fp);
	  strcpy(gpio_value,"0");  // Write 0
	  fwrite(&gpio_value, sizeof(char) ,1 , fp);
	  fclose(fp);

	  usleep( 1000 );	// 0.0001 sec delay

	  printf("dogm_cmd_mode\n");
}

void dog_data_mode(void)
{
	  FILE *fp;
	  char gpio_value[4];


	  fp = fopen("/sys/class/gpio/gpio21/value","rb+");
	  if (fp == NULL) {
		  printf("dog_data_mode: Can't open /sys/class/gpio/gpio21/value\n");
		  return;
	  }
	  rewind(fp);
	  strcpy(gpio_value,"1");  // Write 1
	  fwrite(&gpio_value, sizeof(char) ,1 , fp);
	  fclose(fp);

	  usleep( 1000 );	// 0.01 sec delay

	  printf("dogm_data_mode\n");

}



