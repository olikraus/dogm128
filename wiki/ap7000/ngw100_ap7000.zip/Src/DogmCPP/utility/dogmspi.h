#ifndef dogmspi_h
#define dogmspi_h

extern int dog_display_reset(void);
extern void dog_spi_open(void);
extern unsigned char dog_spi_out(unsigned char data);
extern void dog_cmd_mode(void);
extern void dog_data_mode(void);

#endif
