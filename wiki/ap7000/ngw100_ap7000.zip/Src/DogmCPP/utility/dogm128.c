/*

  dogm128.c
  
  (c) 2010 Oliver Kraus (olikraus@gmail.com)
  
  graphic functions for the dogm128 graphics module 
  with ST7565R controller from electronic assembly
  
  optimized c-code for avr-gcc


  This file is part of the dogm128 Arduino library.

  The dogm128 library is free software: you can redistribute it and/or modify
  it under the terms of the Lesser GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  The dogm128 library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  Lesser GNU General Public License for more details.

  You should have received a copy of the Lesser GNU General Public License
  along with dogm128.  If not, see <http://www.gnu.org/licenses/>.


  ST7565R SPI interface
  
    ST7565R reads data with rising edge of the clock signal (SCL)
      --> CPHA = 0 and CPOL = 0
    ST7565R reads  MSB first 
      --> DORD = 0
  
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>  // usleep
#include "dogm128.h"
#include "dogmspi.h"




unsigned char dog_page_buffer[DOG_PAGE_SIZE];
uint8_t dog_curr_page = 0;	/* 0...DOG_PAGE_CNT-1 */
uint8_t dog_min_y = 0;
uint8_t dog_max_y = DOG_PAGE_HEIGHT-1;


uint8_t dog_spi_result = 0;		/* last value returned from SPI system (after executing the picture loop) */

/*==============================================================*/
/* 
  SPI subsystem  for Arduino
  Pins 15 to 19 (ATMEGA8) or 10 to 13 (Arduino) are used.
*/
/*==============================================================*/








void dog_init_display(void) {

    printf("dog_init_display\n");

  dog_spi_open();
  dog_display_reset();	/* force reset of the spi subsystem of the ST7565R */
  dog_cmd_mode();
  /* mostly taken from the EA dogm description */
  dog_spi_out(0x040);		/* set display start line to 0 */
  dog_spi_out(0x0a1);		/* ADC set to reverse */
  dog_spi_out(0x0c0);		/* common output mode */
  dog_spi_out(0x0a6);		/* display normal, bit val 0: LCD pixel off. */
  dog_spi_out(0x0a2);		/* LCD bias 1/9 */
  dog_spi_out(0x02f);		/* all power  control circuits on */
  dog_spi_out(0x0f8);		/* set booster ratio to */
  dog_spi_out(0x000);		/* 4x */
  dog_spi_out(0x027);		/* set V0 voltage resistor ratio to large */
  dog_spi_out(0x081);		/* set contrast */
  dog_spi_out(0x016);		/* contrast value, EA default: 0x016 */
  dog_spi_out(0x0ac);		/* indicator */
  dog_spi_out(0x000);		/* disable */
  dog_spi_out(0x0af);		/* display on */

  dog_spi_out(0x0a5);		/* display all points, ST7565, UC1610 */
  usleep(1000000);			// 1 second
  dog_spi_out(0x0a4);		/* normal display  */

}



static void dog_transfer_sub_page(uint8_t page, uint8_t  offset)
{
  uint8_t idx;
  uint8_t *buffer = dog_page_buffer;
  
  buffer += offset;

  /* enable and reset com interface of the ST7565R */

  
#ifdef DOG_REVERSE
  
#if defined(DOGXL160_HW_BW)
#if defined(DOG_DOUBLE_MEMORY)
  page--;
#endif
  dog_cmd_mode();
  dog_spi_out(0x060 | (page*2) );		/* select current page  (UC1610)*/
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
  dog_data_mode();
  idx = 0;
  while( idx != DOG_PAGE_WIDTH )
  {
    dog_spi_out(dog_4to8[buffer[idx] & 15]); 
    idx++;
  }  
  dog_cmd_mode();
  dog_spi_out(0x060 | ((page*2)+1) );		/* select current page  (UC1610)*/
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
  dog_data_mode();
  idx = 0;
  while( idx != DOG_PAGE_WIDTH )
  {
    dog_spi_out(dog_4to8[(buffer[idx] >> 4)&15]); 
    idx++;
  }  
#else
  /* set write position */
  dog_cmd_mode();
#ifdef DOGXL160_HW_GR
  dog_spi_out(0x060 | (page) );		/* select current page  (UC1610)*/
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
#else
  dog_spi_out(0x0b0 | page );		/* select current page (ST7565R) */
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
#endif
  /* send a complete page */
  dog_data_mode();
  idx = 0;
  while( idx != DOG_PAGE_WIDTH )
  {
    dog_spi_out(buffer[idx] );
    idx++;
  }
#endif
  
#else /* DOG_REVERSE */
  
#if defined(DOGXL160_HW_BW)
  dog_cmd_mode();
  dog_spi_out(0x060 | (page*2) );		/* select current page  (UC1610)*/
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
  dog_data_mode();
  idx = DOG_PAGE_WIDTH;
  while( idx != 0 )
  {
    idx--;
    dog_spi_out(dog_4to8[buffer[idx] & 15]); 
  }  
  dog_cmd_mode();
  dog_spi_out(0x060 | ((page*2)+1) );		/* select current page  (UC1610)*/
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
  dog_data_mode();
  idx = DOG_PAGE_WIDTH;
  while( idx != 0 )
  {
    idx--;
    dog_spi_out(dog_4to8[(buffer[idx] >> 4)&15]); 
  }  
#else
  /* set write position */
  dog_cmd_mode();
#ifdef DOGXL160_HW_GR
  dog_spi_out(0x060 | (page) );		/* select current page  (UC1610)*/
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
#else
  dog_spi_out(0x0b0 | page );		/* select current page (ST7565R) */
  dog_spi_out(0x010 );		/* set upper 4 bit of the col adr to 0 */
  dog_spi_result = dog_spi_out(0x000 );		/* set lower 4 bit of the col adr to 0 */
#endif
  
  /* send a complete page */
  dog_data_mode();
  idx = DOG_PAGE_WIDTH;
  while( idx != 0 )
  {
    idx--;
    dog_spi_out(buffer[idx] ); 
  }
#endif
  
#endif

  /* disable com interface of the ST7565R */


}

static void dog_transfer_page(void)
{
#if defined(DOG_DOUBLE_MEMORY)
#if defined(DOG_REVERSE)
  dog_transfer_sub_page(dog_curr_page*2, DOG_WIDTH);
  dog_transfer_sub_page(dog_curr_page*2+1, 0);
#else
  dog_transfer_sub_page(dog_curr_page*2, 0);
  dog_transfer_sub_page(dog_curr_page*2+1, DOG_WIDTH);
#endif
#else
  dog_transfer_sub_page(dog_curr_page, 0);
#endif
  
}
/*==============================================================*/
/* page buffer functions */
/*==============================================================*/

static void dog_ClearPage(void)
{
  uint16_t i;
  for( i = 0; i < DOG_PAGE_SIZE; i++ )
  {
    dog_page_buffer[i] = 0;
  }
}

void dog_StartPage(void)
{
#ifdef DOG_REVERSE
  dog_curr_page = DOG_PAGE_CNT - 1;
#else
  dog_curr_page = 0;
#endif
  dog_min_y = 0;
  dog_max_y = DOG_PAGE_HEIGHT-1;
  dog_ClearPage();
}

uint8_t dog_NextPage(void)
{
  dog_transfer_page();
  dog_ClearPage();
  
#ifdef DOG_REVERSE
  if ( dog_curr_page == 0 )
      return 0;
  dog_curr_page--;
#else
  dog_curr_page++;
  if ( dog_curr_page >= DOG_PAGE_CNT )
      return 0;
#endif  
 
/*  
  dog_min_y = DOG_PAGE_HEIGHT;
  dog_min_y *= dog_curr_page;
  dog_max_y = dog_min_y;
  dog_max_y += DOG_PAGE_HEIGHT-1;
*/
  
  dog_min_y += DOG_PAGE_HEIGHT;
  dog_max_y += DOG_PAGE_HEIGHT;
  return 1;
}

