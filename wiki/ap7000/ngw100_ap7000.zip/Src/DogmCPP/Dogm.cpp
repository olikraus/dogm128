
#include <unistd.h>  // usleep
#include "Dogm.hpp"



Dogm::Dogm(void) {

  rot = 0;
  size = 0;
  tx = 0;
  ty = 0;
  libinfo_done = 0;
  // why can dog_Init() not be called here... arduino will hang if this is done in the constructor
  // should be investigated some day
  dog_init_display();
}




void Dogm::start(void)
{

  dog_StartPage();
}

// values between 0 and 63 allowed
void Dogm::setContrast(uint8_t val)
{
  dog_SetContrast(val);
}

void Dogm::setInvertPixelMode(uint8_t val)
{
  if ( is_req_init )
    Init();
  dog_SetInvertPixelMode(val);
}



void Dogm::xy_char_correction(uint8_t len)
{
  switch( rot )
  {
    default:
      tx += len;
      break;
    case 1:
      ty += len;
      break;
    case 2:
      tx -= len;
      break;
    case 3:
      ty -= len;
      break;
  }
}

void Dogm::drawChar(uint8_t c) 
{
  xy_char_correction(dog_DrawRChar(tx, ty, rot, fptr, c));  
}
void Dogm::drawStr(const char *s) 
{ 
  xy_char_correction(dog_DrawRStr(tx, ty, rot, fptr, s));
}

void Dogm::showLibInfo(void)
{
  if ( libinfo_done == 0 )
  {
    start();
    do
    {
      libinfo_draw();
    } while( next() );
    libinfo_done = 1;
    usleep(200000); // 2 sec sleep
  }
}

